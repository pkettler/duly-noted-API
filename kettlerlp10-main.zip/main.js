import http from 'http';

const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
  const page = parsedUrl.searchParams.get('page');
  const num1 = parsedUrl.searchParams.get('num1');
  const num2 = parsedUrl.searchParams.get('num2');
  const sum = Number(num1) + Number(num2);

  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/html');
  res.end(`
    <html>
        <body>
            <p>${num1} + ${num2} = ${sum}</p>
        </body>
    </html>
    `);
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
